# React Examples (Vite)

Simple Vite-powered React project containing several small example components.

Run locally:

```powershell
npm install
npm run dev
```

Files of interest:
- `src/examples` - individual example components
- `src/App.jsx` - combines all examples on one page
